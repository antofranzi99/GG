SLIMEBOUND: BOSSFALL — MOBILE WEB APP BUILD v124

Metodo consigliato per iPhone:
1. Carica questa cartella o questo ZIP su Netlify Drop, Itch.io, GitHub Pages o Vercel.
2. Apri il link finale da Safari su iPhone.
3. Premi Condividi.
4. Premi Aggiungi alla schermata Home.
5. Apri il gioco dall'icona creata.

Consiglio: giocalo in orizzontale.

Per Netlify Drop:
- Vai su Netlify Drop.
- Trascina direttamente la cartella oppure lo ZIP.
- Apri il link generato su Safari.

Per Itch.io:
- Crea nuovo progetto.
- Tipo: HTML.
- Carica lo ZIP.
- Imposta index.html come file principale.

Nota:
Aprire index.html come anteprima file su iPhone può dare problemi con touch, audio e salvataggi.
Un URL web vero è molto più stabile.


v125: mano del giocatore e carte rifatte per migliore stabilità e leggibilità su iPhone/Safari.
